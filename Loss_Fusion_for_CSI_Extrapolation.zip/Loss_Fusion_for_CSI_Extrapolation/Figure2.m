%{
 @ File: Figure2.m
 @ Time: (UTC+8) 2023/09/26 10:09:23
 @ Description: Run this script to generate Figure 2 in the paper.
%}

clc; clear; close all;

% load data from files
rates = zeros(16, 6001);
load("./record/Sumloss1.58_result.mat")
rate = squeeze(mean(mean(loss_eval, 1), 2));
rates(1, :) = rate;
load("./record/Sumloss3.17_result.mat")
rate = squeeze(mean(mean(loss_eval, 1), 2));
rates(2, :) = rate;
load("./record/Sumloss6.33_result.mat")
rate = squeeze(mean(mean(loss_eval, 1), 2));
rates(3, :) = rate;
load("./record/Sumloss12.67_result.mat")
rate = squeeze(mean(mean(loss_eval, 1), 2));
rates(4, :) = rate;
load("./record/Sumloss25.33_result.mat")
rate = squeeze(mean(mean(loss_eval, 1), 2));
rates(5, :) = rate;
load("./record/Sumloss50.66_result.mat")
rate = squeeze(mean(mean(loss_eval, 1), 2));
rates(6, :) = rate;
load("./record/Sumloss101.33_result.mat")
rate = squeeze(mean(mean(loss_eval, 1), 2));
rates(7, :) = rate;
load("./record/Sumloss202.66_result.mat")
rate = squeeze(mean(mean(loss_eval, 1), 2));
rates(8, :) = rate;
load("./record/Sumloss405.32_result.mat")
rate = squeeze(mean(mean(loss_eval, 1), 2));
rates(9, :) = rate;
load("./record/Sumloss810.64_result.mat")
rate = squeeze(mean(mean(loss_eval, 1), 2));
rates(10, :) = rate;
load("./record/Sumloss1621.28_result.mat")
rate = squeeze(mean(mean(loss_eval, 1), 2));
rates(11, :) = rate;
load("./record/Sumloss3242.56_result.mat")
rate = squeeze(mean(mean(loss_eval, 1), 2));
rates(12, :) = rate;
load("./record/Sumloss6485.12_result.mat")
rate = squeeze(mean(mean(loss_eval, 1), 2));
rates(13, :) = rate;
load("./record/Sumloss12970.23_result.mat")
rate = squeeze(mean(mean(loss_eval, 1), 2));
rates(14, :) = rate;
load("./record/Sumloss25940.47_result.mat")
rate = squeeze(mean(mean(loss_eval, 1), 2));
rates(15, :) = rate;
load("./record/Sumloss51880.93_result.mat")
rate = squeeze(mean(mean(loss_eval, 1), 2));
rates(16, :) = rate;

% halving
num_paras = 16;
total_epoch = 1600;
init_epoch = 10;
halving_times = log2(num_paras); % the number of halving operations
halving_epoch = floor((total_epoch - init_epoch * num_paras) / halving_times); % the number of epochs for each halving round

discarded_epoch = zeros(1, num_paras) + init_epoch; % record the epochs that each parameter is discarded
current_rate = zeros(1, num_paras); % record the newest rate of each parameter to determine whether it is discarded

for time = 1:halving_times

    for idx = 1:num_paras

        if current_rate(idx) ~= -1
            discarded_epoch(idx) = discarded_epoch(idx) + floor(halving_epoch / num_paras * 2 ^ (time - 1));
            current_rate(idx) = rates(idx, discarded_epoch(idx) * 10 + 1);
        end

    end

    [~, sorted_idx] = sort(current_rate); % sort the rates in ascending order
    current_rate(sorted_idx(1:end - num_paras / 2 ^ time)) = -1; % discard the worst half of parameters
end

discarded_epoch(sorted_idx(end)) = 600; % plot the best parameter until the end

% plot
figure(1)
hold on;
grid on;
box on;
colors = ["#D980FA", "#0652DD", "#EA2027", "#009432", "#F79F1F", "#1B1464", "#833471", "#12CBC4"];
curves = gobjects(1, num_paras / 2);
curve_idx = 1;

for idx = 1:num_paras

    if discarded_epoch(idx) ~= 32 % the parameter discarded at the first round is not plotted
        curves(curve_idx) = plot(0.1:0.1:discarded_epoch(idx), smooth(rates(idx, 1:discarded_epoch(idx) * 10)), 'Color', colors(curve_idx), 'LineStyle', '-', 'LineWidth', 2);
        scatter(discarded_epoch(idx):10:600, smooth(rates(idx, discarded_epoch(idx) * 10:100:end)), 30, '.', 'MarkerEdgeColor', colors(curve_idx)); % used to plot the whole curve
        % scatter(discarded_epoch(idx):2:600, smooth(rates(idx, discarded_epoch(idx) * 10:20:end)), 50, '.', 'MarkerEdgeColor', colors(curve_idx)); % used to plot the detailed curve
        curve_idx = curve_idx + 1;
    end

end

%%%%%%%used to plot the whole curve
legend(curves, '$w=12.7$', '$w=25.3$', '$w=50.7$', '$w=101.3$', '$w=202.7$', '$w=405.3$', '$w=810.6$', '$w=1621.3$', 'Location', 'southeast', 'FontSize', 8, 'Interpreter', 'latex');
xlabel('Epoch');
ylabel('System rate (bps/Hz)');
ylim([20, 36]);
%%%%%%%

%%%%%%%used to plot the detailed curve
% xlim([500 600]);
% ylim([33 36]);
% xticks(500:20:600);
% yticks(33:0.5:36)

% xlim([60 200])
% ylim([30 35])
% xticks(60:20:200)
% yticks(30:35)
%%%%%%
