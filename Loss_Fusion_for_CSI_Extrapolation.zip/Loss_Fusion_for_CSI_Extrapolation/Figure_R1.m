%{
 @ File: Figure_R1.m
 @ Time: (UTC+8) 2024/02/25 00:42:40
 @ Description: Run this script to generate Figure to comparing the performances of different learning rates.
%}
clc; clear; close all;

load("./record/RateLoss_lr1e-4_result.mat")
rate1 = squeeze(mean(mean(loss_eval, 1), 2));
load("./record/Rateloss_lr1e-3_result.mat")
rate2 = squeeze(mean(mean(loss_eval, 1), 2));
load("./record/Rateloss_lr1e-5_result.mat")
rate3 = squeeze(mean(mean(loss_eval, 1), 2));
load("./record/Rateloss_lr1e-6_result.mat")
rate4 = squeeze(mean(mean(loss_eval, 1), 2));

figure(1)
hold on
grid on;
box on;
plot(0:0.1:600, rate1, 'LineWidth', 1.5, 'Color', '#c0392b');
plot(0:0.1:600, rate2, 'LineWidth', 1.5, 'Color', '#27ae60');
plot(0:0.1:600, rate3, 'LineWidth', 1.5, 'Color', '#3498db');
plot(0:0.1:600, rate4, 'LineWidth', 1.5, 'Color', '#f39c12');
xlabel('Epoch');
ylabel('System rate (bps/Hz)');
legend('Learning rate=1e-3', 'Learning rate=1e-4', 'Learning rate=1e-5', 'Learning rate=1e-6', 'Interpreter', 'latex', 'Location', 'southeast');
xlim([0, 600]);
ylim([8, 37]);
