'''
 @ File: model.py
 @ Time: 2022/08/12 15:19:54
 @ Description: The model to extrapolate unmeasured CSI based on measured CSI
'''

import torch
import torch.nn as nn


class Model(nn.Module):
    def __init__(self,
                 BS_antennas=32,
                 num_UE=5,
                 num_RB=8,
                 device=torch.device("cuda:0" if torch.cuda.is_available() else "cpu")):
        """Initialize the model

        Args:
            BS_antennas (int, optional): number of BS antennas. Defaults to 32.
            num_UE (int, optional): number of UEs. Defaults to 5.
            num_RB (int, optional): number of RBs. Defaults to 8.
            device (str, optional): device to run the model. Defaults to torch.device("cuda:0" if torch.cuda.is_available() else "cpu").
        """
        super(Model, self).__init__()

        self.BS_antennas = BS_antennas
        self.num_UE = num_UE
        self.num_RB = num_RB
        self.device = device

        self.cnn = nn.Sequential(
            nn.Conv2d(in_channels=2, out_channels=256,
                      kernel_size=(1, 3), stride=(1, 3), padding=(0, 1)),
            nn.BatchNorm2d(256),
            nn.LeakyReLU(0.1),
            nn.Conv2d(in_channels=256, out_channels=512,
                      kernel_size=(1, 3), stride=(1, 3), padding=(0, 1)),
            nn.BatchNorm2d(512),
            nn.LeakyReLU(0.1),
            nn.Conv2d(in_channels=512, out_channels=512,
                      kernel_size=(1, 3), stride=(1, 3), padding=(0, 1)),
            nn.BatchNorm2d(512),
            nn.LeakyReLU(0.1)
        )

        self.lstm = nn.LSTM(input_size=512, hidden_size=512,
                            num_layers=2, dropout=0.02)
        self.drop = nn.Dropout(0.02)

        self.fc = nn.Linear(512, 2 * self.BS_antennas)

    def forward(self, CSI_measured):
        """Forward propagation

        Args:
            CSI_measured (tensor): input CSI in shape (batch_size, 5(num_UE), 32(BS antennas), 8(num_RB))

        Returns:
            tensor: extrapolated CSI in shape (batch_size, 2(Re&Im), 5(num_UE)*8(num_RB), 32(BS_antennas))
        """

        # normalize the CSI of each user
        max_CSI = torch.amax(torch.abs(CSI_measured.reshape(CSI_measured.shape[0],
                                                                  CSI_measured.shape[1], -1)), dim=2)  # calculate the maximun CSI element of each UE in shape (batch, 5(num_UE))
        CSI_measured = CSI_measured.permute(0, 1, 3, 2).reshape(
            CSI_measured.shape[0], CSI_measured.shape[1], -1)  # (batch, 5(num_UE), 8(num_RB)*32(BS antennas))
        # (8(num_RB)*32(BS antennas), batch, 5(num_UE))
        CSI_measured = CSI_measured.permute(2, 0, 1) / max_CSI
        # (batch, 5(num_UE), 8(num_RB)*32(BS antennas))
        CSI_measured = CSI_measured.permute(1, 2, 0)
        # (batch, 5(num_UE)*8(num_RB), 32(BS antennas))
        CSI_measured = CSI_measured.reshape(
            CSI_measured.shape[0], CSI_measured.shape[1] * self.num_RB, self.BS_antennas)

        # use real and imaginary part as two channels
        # (batch, 2(Re&Im), 5(num_UE)*8(num_RB), 32(BS antennas))
        CSI_measured = torch.stack(
            (CSI_measured.real, CSI_measured.imag), dim=1)

        # pass through CNN
        feature_measured = self.cnn(CSI_measured)
        feature_measured = nn.AvgPool2d(kernel_size=(
            1, feature_measured.shape[3]))(feature_measured)
        feature_measured = feature_measured.squeeze()  # (batch, 512, 5(num_UE)*8(num_RB))
        feature_measured = feature_measured.reshape(feature_measured.shape[0], feature_measured.shape[1], self.num_UE, self.num_RB).permute(
            3, 0, 2, 1)  # (batch, 512, 5(num_UE), 8(num_RB)) to (8(num_RB), batch, 5(num_UE), 512)
        feature_measured = feature_measured.reshape(
            feature_measured.shape[0], -1, feature_measured.shape[3])  # (8(num_RB), batch*5(num_UE), 512)

        # pass through sequential LSTMs
        for RB in range(self.num_RB):
            if RB == 0:
                output, (hn, cn) = self.lstm(feature_measured)
                output = output[-1, :, :].unsqueeze(0)
                output_sery = output
            else:
                output, (hn, cn) = self.lstm(output, (hn, cn))
                output_sery = torch.cat((output_sery, output), dim=0)

        # (8(num_RB), batch*5(num_UE), 512)
        output_sery = self.drop(output_sery)
        # (8(num_RB), batch*5(num_UE), 2(Re&Im)*32(BS antennas))
        CSI_extrapolated = self.fc(output_sery)

        # (batch, 2, 5(num_UE), 8(num_RB), 32(BS_antennas))
        CSI_extrapolated = CSI_extrapolated.reshape(
            self.num_RB, -1, self.num_UE, 2, self.BS_antennas).permute(1, 3, 2, 0, 4)
        # (batch, 2, 5(num_UE)*8(num_RB), 32(BS_antennas))
        CSI_extrapolated = CSI_extrapolated.reshape(
            CSI_extrapolated.shape[0], CSI_extrapolated.shape[1], -1, CSI_extrapolated.shape[4])

        # add shortcut connection
        # (batch, 2, 5(num_UE), 8(num_RB), 32(BS_antennas))
        CSI_measured = CSI_measured.reshape(
            CSI_measured.shape[0], 2, self.num_UE, self.num_RB, self.BS_antennas)
        # (batch, 2, 5(num_UE)*8(num_RB), 32(BS_antennas))
        CSI_measured = CSI_measured[:, :, :, -1,
                                        :].repeat_interleave(self.num_RB, dim=2)
        CSI_extrapolated = CSI_extrapolated + CSI_measured

        return CSI_extrapolated
