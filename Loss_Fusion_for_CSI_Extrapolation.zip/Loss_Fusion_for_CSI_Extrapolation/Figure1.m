%{
 @ File: Figure1.m
 @ Time: (UTC+8) 2023/10/07 11:44:22
 @ Description: Run this script to generate Figure 1 in the paper.
%}
clc; clear; close all;

x = 0:2 * pi / 100:2 * pi;
y1 = sin(x); % the real part of CSI variations track
y2 = cos(x); % the imaginary part of CSI variations track

figure(1);
plot(x, y1, 'r', 'LineWidth', 2, 'LineStyle', ':');
hold on;
plot(x, y2, 'b', 'LineWidth', 2, 'LineStyle', ':');
grid on;

% set the path delay to 3.82us, then the phase shift is 3.82us * 180kHz * 2 * pi = 11 * pi / 8 = 7 * pi / 4 - 3 * pi / 8
x1 = 3 * pi / 8; % the first RB
y11 = sin(x1);
y21 = cos(x1);
x2 = 7 * pi / 4; % the second RB
y12 = sin(x2);
y22 = cos(x2);
x3 = 3 * pi / 2; % the output of the network
y13 = y11 + (y12 - y11) / (x2 - x1) * (x3 - x1);
y23 = y21 + (y22 - y21) / (x2 - x1) * (x3 - x1);

line([x1, x2], [y11, y12], 'LineStyle', '--', 'Color', 'r');
line([x1, x2], [y21, y22], 'LineStyle', '--', 'Color', 'b');

plot(x1, y11, 'rx', 'MarkerSize', 10, 'LineWidth', 1);
plot(x1, y21, 'bx', 'MarkerSize', 10, 'LineWidth', 1);
plot(x2, y12, 'ro', 'MarkerSize', 7, 'LineWidth', 1);
plot(x2, y22, 'bo', 'MarkerSize', 7, 'LineWidth', 1);
plot(x3, y13, 'r.', 'MarkerSize', 20, 'LineWidth', 1);
plot(x3, y23, 'b.', 'MarkerSize', 20, 'LineWidth', 1);

xlim([0, 2 * pi]);
xticks([pi / 32, 3 * pi / 8, 23 * pi / 32, 17 * pi / 16, 45 * pi / 32, 7 * pi / 4]);
xticklabels({'-45', '0', '45', '90', '135', '180'});

legend('Real part of CSI variations track', 'Imaginary part of CSI variations track', 'Real part of gradient direction', 'Imaginary part of gradient direction', 'Location', 'SouthWest');
xlabel("Relative frequency (kHz)")
ylabel("Normalized magnitude")
