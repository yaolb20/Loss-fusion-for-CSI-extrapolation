%{
 @ File: Figure3.m
 @ Time: (UTC+8) 2023/10/08 15:31:33
 @ Description: Run this script to generate Figure 3 in the paper.
%}

clc; clear; close all;

% Load the data from files
load("./record/L1loss_result.mat")
loss_eval = squeeze(mean(loss_eval, 1));
std1 = std(loss_eval);
std1 = transpose(smooth(std1));
rate1 = squeeze(mean(loss_eval, 1));
up_bound1 = rate1 + std1;
low_bound1 = rate1 - std1;
load("./record/MSEloss_result.mat")
loss_eval = squeeze(mean(loss_eval, 1));
std2 = std(loss_eval);
std2 = transpose(smooth(std2));
rate2 = squeeze(mean(loss_eval, 1));
up_bound2 = rate2 + std2;
low_bound2 = rate2 - std2;
load("./record/Rateloss_result.mat")
loss_eval = squeeze(mean(loss_eval, 1));
std3 = std(loss_eval);
std3 = transpose(smooth(std3));
rate3 = squeeze(mean(loss_eval, 1));
up_bound3 = rate3 + std3;
low_bound3 = rate3 - std3;
load("./record/FusedLoss50.66_result.mat")
loss_eval = squeeze(mean(loss_eval, 1));
std4 = std(loss_eval);
std4 = transpose(smooth(std4));
rate4 = squeeze(mean(loss_eval, 1));
up_bound4 = rate4 + std4;
low_bound4 = rate4 - std4;

figure(1)
hold on
grid on;
box on;
% plot curves
plot(0:0.1:600, rate1, 'LineWidth', 2, 'Color', '#c0392b', 'LineStyle', '-.');
plot(0:0.1:600, rate2, 'LineWidth', 2, 'Color', '#27ae60', 'LineStyle', '--');
plot(0:0.1:600, rate3, 'LineWidth', 2, 'Color', '#3498db', 'LineStyle', ':');
plot(0:0.1:600, rate4, 'LineWidth', 2, 'Color', '#f39c12', 'LineStyle', '-');
% plot error bars
x = 0:0.1:600;
errorbar1 = fill([x, fliplr(x)], [low_bound1, fliplr(up_bound1)], [0.7500, 0.2227, 0.1680], 'FaceAlpha', 0.3, 'EdgeColor', 'none');
errorbar2 = fill([x, fliplr(x)], [low_bound2, fliplr(up_bound2)], [0.1523, 0.6797, 0.3750], 'FaceAlpha', 0.3, 'EdgeColor', 'none');
errorbar3 = fill([x, fliplr(x)], [low_bound3, fliplr(up_bound3)], [0.2031, 0.5938, 0.8555], 'FaceAlpha', 0.3, 'EdgeColor', 'none');
errorbar4 = fill([x, fliplr(x)], [low_bound4, fliplr(up_bound4)], [0.9492, 0.6094, 0.0703], 'FaceAlpha', 0.3, 'EdgeColor', 'none');
%%%%%plot the whole curves
xlabel('Epoch');
ylabel('System rate (bps/Hz)');
legend('L1 loss [7]', 'MSE loss [4]', 'Negative system rate [10]', 'Fused loss ($w=50.7)$', 'Interpreter', 'latex', 'Location', 'southwest');
xlim([0, 600]);
ylim([8, 37]);
%%%%%

%%%%%plot the detailed curves
% xlim([0, 5]);
% ylim([8, 27]);
% xticks(0:1:5);

% xlim([580, 600]);
% ylim([30, 37]);
% xticks(580:5:600);
%%%%
