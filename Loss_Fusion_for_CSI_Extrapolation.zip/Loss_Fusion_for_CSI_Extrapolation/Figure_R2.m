%{
 @ File: Figure_R2.m
 @ Time: (UTC+8) 2024/02/25 00:43:00
 @ Description: Run this script to generate Figure comparing the performances of negative system rate loss and the fused loss under different simulation settings.
%}
clc; clear; close all;

load("./record/Sumloss_lr1e-3_result.mat")
rate1 = squeeze(mean(mean(loss_eval, 1), 2));
load("./record/Rateloss_lr1e-3_result.mat")
rate2 = squeeze(mean(mean(loss_eval, 1), 2));
figure(1)
hold on
grid on;
box on;
plot(0:0.1:600, rate1, 'LineWidth', 1.5, 'Color', '#c0392b');
plot(0:0.1:600, rate2, 'LineWidth', 1.5, 'Color', '#27ae60');
xlabel('Epoch');
ylabel('System rate (bps/Hz)');
legend('Fused loss', 'Negative system rate', 'Interpreter', 'latex', 'Location', 'southeast');
xlim([0, 600]);
ylim([15, 37]);

load("./record/Sumloss_lr1e-5_result.mat")
rate1 = squeeze(mean(mean(loss_eval, 1), 2));
load("./record/Rateloss_lr1e-5_result.mat")
rate2 = squeeze(mean(mean(loss_eval, 1), 2));
figure(2)
hold on
grid on;
box on;
plot(0:0.1:600, rate1, 'LineWidth', 1.5, 'Color', '#c0392b');
plot(0:0.1:600, rate2, 'LineWidth', 1.5, 'Color', '#27ae60');
xlabel('Epoch');
ylabel('System rate (bps/Hz)');
legend('Fused loss', 'Negative system rate', 'Interpreter', 'latex', 'Location', 'southeast');
xlim([0, 600]);
ylim([15, 33]);

load("./record/Sumloss_lr1e-6_result.mat")
rate1 = squeeze(mean(mean(loss_eval, 1), 2));
load("./record/Rateloss_lr1e-6_result.mat")
rate2 = squeeze(mean(mean(loss_eval, 1), 2));
figure(3)
hold on
grid on;
box on;
plot(0:0.1:600, rate1, 'LineWidth', 1.5, 'Color', '#c0392b');
plot(0:0.1:600, rate2, 'LineWidth', 1.5, 'Color', '#27ae60');
xlabel('Epoch');
ylabel('System rate (bps/Hz)');
legend('Fused loss', 'Negative system rate', 'Interpreter', 'latex', 'Location', 'southeast');
xlim([0, 600]);
ylim([12, 29]);

load("./record/Sumloss_width128_result.mat")
rate1 = squeeze(mean(mean(loss_eval, 1), 2));
load("./record/Rateloss_width128_result.mat")
rate2 = squeeze(mean(mean(loss_eval, 1), 2));
figure(4)
hold on
grid on;
box on;
plot(0:0.1:600, rate1, 'LineWidth', 1.5, 'Color', '#c0392b');
plot(0:0.1:600, rate2, 'LineWidth', 1.5, 'Color', '#27ae60');
xlabel('Epoch');
ylabel('System rate (bps/Hz)');
legend('Fused loss', 'Negative system rate', 'Interpreter', 'latex', 'Location', 'southeast');
xlim([0, 600]);
ylim([15, 33]);

load("./record/Sumloss_width512_result.mat")
rate1 = squeeze(mean(mean(loss_eval, 1), 2));
load("./record/Rateloss_width512_result.mat")
rate2 = squeeze(mean(mean(loss_eval, 1), 2));
figure(5)
hold on
grid on;
box on;
plot(0:0.1:600, rate1, 'LineWidth', 1.5, 'Color', '#c0392b');
plot(0:0.1:600, rate2, 'LineWidth', 1.5, 'Color', '#27ae60');
xlabel('Epoch');
ylabel('System rate (bps/Hz)');
legend('Fused loss', 'Negative system rate', 'Interpreter', 'latex', 'Location', 'southeast');
xlim([0, 600]);
ylim([15, 41]);

load("./record/Sumloss_width1024_result.mat")
rate1 = squeeze(mean(mean(loss_eval, 1), 2));
load("./record/Rateloss_width1024_result.mat")
rate2 = squeeze(mean(mean(loss_eval, 1), 2));
figure(6)
hold on
grid on;
box on;
plot(0:0.1:600, rate1, 'LineWidth', 1.5, 'Color', '#c0392b');
plot(0:0.1:600, rate2, 'LineWidth', 1.5, 'Color', '#27ae60');
xlabel('Epoch');
ylabel('System rate (bps/Hz)');
legend('Fused loss', 'Negative system rate', 'Interpreter', 'latex', 'Location', 'southeast');
xlim([0, 600]);
ylim([15, 45]);

load("./record/Sumloss_depth5_result.mat")
rate1 = squeeze(mean(mean(loss_eval, 1), 2));
load("./record/Rateloss_depth5_result.mat")
rate2 = squeeze(mean(mean(loss_eval, 1), 2));
figure(7)
hold on
grid on;
box on;
plot(0:0.1:600, rate1, 'LineWidth', 1.5, 'Color', '#c0392b');
plot(0:0.1:600, rate2, 'LineWidth', 1.5, 'Color', '#27ae60');
xlabel('Epoch');
ylabel('System rate (bps/Hz)');
legend('Fused loss', 'Negative system rate', 'Interpreter', 'latex', 'Location', 'southeast');
xlim([0, 600]);
ylim([15, 39]);

load("./record/Sumloss_depth7_result.mat")
rate1 = squeeze(mean(mean(loss_eval, 1), 2));
load("./record/Rateloss_depth7_result.mat")
rate2 = squeeze(mean(mean(loss_eval, 1), 2));
figure(8)
hold on
grid on;
box on;
plot(0:0.1:600, rate1, 'LineWidth', 1.5, 'Color', '#c0392b');
plot(0:0.1:600, rate2, 'LineWidth', 1.5, 'Color', '#27ae60');
xlabel('Epoch');
ylabel('System rate (bps/Hz)');
legend('Fused loss', 'Negative system rate', 'Interpreter', 'latex', 'Location', 'southeast');
xlim([0, 600]);
ylim([15, 39]);

load("./record/Sumloss_depth9_result.mat")
rate1 = squeeze(mean(mean(loss_eval, 1), 2));
load("./record/Rateloss_depth9_result.mat")
rate2 = squeeze(mean(mean(loss_eval, 1), 2));
figure(9)
hold on
grid on;
box on;
plot(0:0.1:600, rate1, 'LineWidth', 1.5, 'Color', '#c0392b');
plot(0:0.1:600, rate2, 'LineWidth', 1.5, 'Color', '#27ae60');
xlabel('Epoch');
ylabel('System rate (bps/Hz)');
legend('Fused loss', 'Negative system rate', 'Interpreter', 'latex', 'Location', 'southeast');
xlim([0, 600]);
ylim([15, 39]);
