'''
 @ File: train_eval.py
 @ Time: (UTC+8) 2023/08/21 13:02:18
 @ Description: Train the model for one epoch and evaluate it during training.
'''
import torch
import numpy as np
from utils.loss.rate_for_multi_UE import rate_for_multi_UE
from utils.eval import eval


def train_eval(model, train_loader, eval_loader, optimizer, weight, sigma=2.26e-10, use_fused_loss=True):
    """train the model for one epoch and evaluate it during training

    Args:
        model (Model): model
        train_loader (Dataloader): dataloader for training
        eval_loader (Dataloader): dataloader for evaluation
        optimizer (torch.optim): optimizer
        weight (int): weight to balance CSI extrapolation loss and rate loss
        sigma (float, optional): power of additive gauss noise. Defaults to 2.26e-10.
        use_fused_loss (bool, optional): use fused loss or not. Defaults to True.

    Returns:
        avg_loss (float): average loss of the epoch
        loss_eval (np.array): loss of the evaluation set in each epoch
    """
    running_loss = 0
    CSIloss_func = torch.nn.L1Loss() # modified this line to change between L1 and MSE loss
    eval_loop = round(len(train_loader) / 10)  # calculate the number of training samples between two evaluations, len(train_loader) = 1600
    loss_eval = np.zeros((8, 10)) # 8: 8 RBs; 10: 10 times evaluation in each epoch

    for batch_idx, CSI_load in enumerate(train_loader):
        model.train()
        # (batch_size, 5(num_UE), 32(BS antennas), 8(num_RB))
        CSI_measured = CSI_load[:, :, :, 0: CSI_load.shape[3] // 2]
        CSI_label = CSI_load[:, :, :, CSI_load.shape[3] //
                                        2: CSI_load.shape[3]].permute(0, 1, 3, 2)  # (batch_size, 5(num_UE), 8(num_RB), 32(BS antennas))
        CSI_label_unnorm = CSI_label.permute(
            2, 0, 1, 3)  # (8(num_RB), batch_size, 5(num_UE), 32(BS antennas))

        # normalize the label CSI of each user
        max_CSI = torch.amax(torch.abs(CSI_label.reshape(CSI_label.shape[0],
                                                                    CSI_label.shape[1], -1)), dim=2)  # the maximun CSI element of each user in shape (batch, 5(num_UE))
        # (batch, 5(num_UE), 8(num_RB)*32(BS antennas))
        CSI_label = CSI_label.reshape(
            CSI_label.shape[0], CSI_label.shape[1], -1)
        # (8(num_RB)*32(BS antennas), batch, 5(num_UE))
        CSI_label = CSI_label.permute(2, 0, 1) / max_CSI
        # (batch, 5(num_UE), 8(num_RB)*32(BS antennas))
        CSI_label = CSI_label.permute(1, 2, 0)
        # (batch, 5(num_UE)*8(num_RB), 32(BS antennas))
        CSI_label = CSI_label.reshape(
            CSI_label.shape[0], CSI_label.shape[1] * CSI_load.shape[3] // 2, CSI_load.shape[2])
        # (batch, 2, 5(num_UE)*8(num_RB), 32(BS antennas))
        CSI_label = torch.stack(
            (CSI_label.real, CSI_label.imag), dim=1)

        # pass the measured CSI through the network
        CSI_extrapolated = model(CSI_measured)  # (batch, 2, 5(num_UE)*8(num_RB), 32(BS antennas))

        # calculate the L1 loss and rate loss
        CSIloss = CSIloss_func(CSI_extrapolated, CSI_label)  # L1 loss
        CSI_extrapolated = CSI_extrapolated.reshape(
            CSI_load.shape[0], 2, CSI_load.shape[1], CSI_load.shape[3] // 2, CSI_load.shape[2]).permute(3, 0, 1, 2, 4)  # (8(num_RB), batch, 2(Re&Im), 5(num_UE), 32(BS antennas))
        CSI_extrapolated = torch.complex(
            CSI_extrapolated[:, :, 0, :, :], CSI_extrapolated[:, :, 1, :, :])  # (8(num_RB), batch, 5(num_UE), 32(BS antennas))
        rate_loss = - torch.mean(rate_for_multi_UE(CSI_extrapolated,
                                                   CSI_label_unnorm, sigma))  # rate loss
        if use_fused_loss:
            loss = CSIloss * weight + rate_loss
        else:
            loss = CSIloss

        loss.backward()
        optimizer.step()
        optimizer.zero_grad()
        running_loss += loss.item()
        if (batch_idx + 1) % eval_loop == 0:
            rate_loss= eval(model, eval_loader, sigma)
            loss_eval[:, batch_idx // eval_loop] = rate_loss

    avg_loss = running_loss / len(train_loader)

    return avg_loss, loss_eval
