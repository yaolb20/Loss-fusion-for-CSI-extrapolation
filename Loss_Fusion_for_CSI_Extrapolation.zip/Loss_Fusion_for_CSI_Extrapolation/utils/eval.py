'''
 @ File: eval.py
 @ Time: (UTC+8) 2023/08/21 13:11:07
 @ Description: Evaluate the model.
'''
import torch
from utils.loss.rate_for_multi_UE import rate_for_multi_UE


def eval(model, loader, sigma=2.26e-10):
    """evaluate the model by calculating its rate on the evaluation dataset

    Args:
        model (Model): model
        loader (Dataloader): evaluation dataloader
        sigma (float, optional): power of additive gauss noise. Defaults to 2.26e-10.

    Returns:
        rate (tensor): average rate of the model
    """
    model.eval()

    num_RB = 8
    running_rate = torch.zeros(num_RB)

    with torch.no_grad():
        for _, CSI_load in enumerate(loader):
            # split the CSI into measured CSI and the label
            # (batch_size, 5(UE number), 32(BS antennas), 8(RB number))
            CSI_measured = CSI_load[:, :,
                                          :, 0: CSI_load.shape[3] // 2]
            CSI_label = CSI_load[:, :, :, CSI_load.shape[3] //
                                            2: CSI_load.shape[3]].permute(0, 1, 3, 2)  # (batch_size, 5, 8, 32)
            CSI_label_unnorm = CSI_label.permute(
                2, 0, 1, 3)  # (8, batch_size, 5, 32)

            # normalize the label CSI of each UE
            max_CSI = torch.amax(torch.abs(CSI_label.reshape(CSI_label.shape[0],
                                                                        CSI_label.shape[1], -1)), dim=2)  # the maximun CSI element of each user in shape (batch, 5)
            CSI_label = CSI_label.permute(0, 1, 3, 2).reshape(
                CSI_label.shape[0], CSI_label.shape[1], -1)  # (batch, 5, 8*32)
            # (8*32, batch, 5)
            CSI_label = CSI_label.permute(2, 0, 1) / max_CSI
            # (batch, 5, 8*32)
            CSI_label = CSI_label.permute(1, 2, 0)
            # (batch, 5*8, 32)
            CSI_label = CSI_label.reshape(
                CSI_label.shape[0], CSI_label.shape[1] * CSI_load.shape[3] // 2, CSI_load.shape[2])
            # (batch, 2, 5*8, 32)
            CSI_label = torch.stack(
                (CSI_label.real, CSI_label.imag), dim=1)

            # pass the measured CSI through the network
            CSI_extrapolated = model(CSI_measured)  # (batch, 2, 5*8, 32)

            CSI_extrapolated = CSI_extrapolated.reshape(
                CSI_load.shape[0], 2, CSI_load.shape[1], CSI_load.shape[3] // 2, CSI_load.shape[2]).permute(3, 0, 1, 2, 4)  # (8, batch, 2, 5, 32)
            CSI_extrapolated = torch.complex(
                CSI_extrapolated[:, :, 0, :, :], CSI_extrapolated[:, :, 1, :, :])  # (8, batch, 5, 32)

            rate = rate_for_multi_UE(
                CSI_extrapolated, CSI_label_unnorm, sigma)

            running_rate += rate.data.cpu()

    # average rate
    rates = running_rate / len(loader)

    return rates
