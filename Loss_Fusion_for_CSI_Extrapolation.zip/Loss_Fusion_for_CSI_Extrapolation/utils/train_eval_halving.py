'''
 @ File: train_eval_halving.py
 @ Time: (UTC+8) 2023/09/25 15:43:30
 @ Description: Call train_eval_halving() to train and evaluate the model for epoch_num epoches. This is used in train_eval_halving.py.
'''
import numpy as np
from utils.train_eval import train_eval


def train_eval_halving(train_loader, eval_loader, model, optimizer, weight,
                       sigma, epoch_num, lr_scheduler):
    """train the model for epoch_num epoches and evaluate it during training

    Args:
        train_loader (Dataloader): dataloader for training
        eval_loader (Dataloader): dataloader for evaluation
        model (Model): model
        optimizer (Optimizer): optimizer
        weight (float): weight
        sigma (float): power of additive gauss noise
        epoch_num (int): epoch number
        lr_scheduler (lr_scheduler): learning rate scheduler

    Returns:
        train_losses (float): average loss in training set
        rate_losses (float): average rate loss in evaluation set
    """

    for _ in range(epoch_num):
        train_losses, eval_losses = train_eval(model, train_loader,
                                               eval_loader, optimizer, weight, sigma)
        rate_losses = eval_losses[:, -1] # get the newest rate loss

        lr_scheduler.step(-np.mean(rate_losses))
    return train_losses, np.mean(rate_losses)
