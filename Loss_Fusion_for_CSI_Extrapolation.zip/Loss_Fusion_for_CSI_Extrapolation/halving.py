'''
 @ File: halving.py
 @ Time: 2022/10/15
 @ Description: Run this file to train and evaluate the model.
'''
import torch
from utils.dataset import CSIDataset
from torch.utils.data import DataLoader
from models.model import Model
from utils.train_eval_halving import train_eval_halving
import time
import math

def main(batch_size=64, sigma=2.26e-10, lr=1e-4, minlr=1e-6,
         reference_weight=405.3198, weight_num=16, max_total_epoch=1600, init_training_epoch=10):
    """main function. Run this function to find the optimal weight using halving algorithm.

    Args:
        batch_size (int, optional): batch size. Defaults to 64.
        sigma (float, optional): power of additive gauss noise. Defaults to 2.26e-10.
        lr (float, optional): learning rate. Defaults to 1e-4.
        minlr (float, optional): minimum learning rate. Defaults to 1e-6.
        reference_weight (float, optional): reference weight. Defaults to 405.3198.
        weight_num (int, optional): the number of weights to be tested. Defaults to 16.
        max_total_epoch (int, optional): maximum total epoches. Defaults to 1600.
        init_training_epoch (int, optional): initial training epoch number. Defaults to 10.
    """
    version_name = 'Halving'
    device = torch.device("cuda:1" if torch.cuda.is_available() else "cpu")
    cur_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    train_folder = './data/train'
    eval_folder = './data/validation'

    print(version_name)
    print('device:%s' % device)
    print('batch_size:%d' % batch_size)
    print('sigma:%e' % sigma)
    print('cur_time:%s' % cur_time)
    print('lr and minlr:(%e,%e)' % (lr, minlr))
    print('reference_weight:%f' % reference_weight)
    print('weight_num:%d' % weight_num)
    print('max_total_epoch:%d' % max_total_epoch)
    print('init_training_epoch:%d' % init_training_epoch)

    train_set = CSIDataset(path=train_folder,
                           batch_size=batch_size,
                           device=device)
    eval_set = CSIDataset(path=eval_folder,
                          batch_size=batch_size,
                          device=device)

    train_loader = DataLoader(train_set, batch_size=batch_size, shuffle=True)
    eval_loader = DataLoader(eval_set, batch_size=batch_size, shuffle=False)

    # prepare for halving algorithm
    # calculate the epochs of halving algorithm
    halving_epoch = (max_total_epoch-weight_num * init_training_epoch)
    weight_list = torch.logspace(math.log2(
        reference_weight)-weight_num/2, math.log2(reference_weight)+weight_num/2-1, weight_num, 2)  # generate the weight list
    # record the newest rate of each model
    rates = torch.zeros(weight_num)
    # record the training epoch of each model
    training_epochs = torch.zeros(weight_num)

    print("weight_list:", weight_list)

    # train the model of each weight for init_training_epoch epochs
    for idx in range(weight_num):
        training_epochs[idx] += init_training_epoch
        model = Model().to(device)
        optimizer = torch.optim.Adam(model.parameters(), lr)
        lr_scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
            optimizer,
            mode='min',
            factor=0.5,
            patience=5,
            verbose=False,
            threshold=0.0001,
            threshold_mode='rel',
            cooldown=0,
            min_lr=minlr,
            eps=1e-10)

        _, rates[idx] = train_eval_halving(train_loader=train_loader, eval_loader=eval_loader, model=model, optimizer=optimizer,
                                                    weight=weight_list[idx], sigma=sigma, epoch_num=init_training_epoch, lr_scheduler=lr_scheduler)

        torch.save({'model_state_dict': model.state_dict(),
                    'optimizer_state_dict': optimizer.state_dict(), 'lr_scheduler_state_dict': lr_scheduler.state_dict()}, "./checkpoints/halving_checkpoint%.5f.pt" % (weight_list[idx]))
        print("model%.3f achieve rate %.2f after %d epochs' training." % (
            weight_list[idx], rates[idx], training_epochs[idx]))

    # halving algorithm
    while len(weight_list) > 1:
        # train the model of each weight for calculated epoches and discard the worst half of the models
        # calculate the number of epochs to train each weight
        training_epoch = int(halving_epoch/len(weight_list)/math.log2(weight_num))
        for idx in range(len(weight_list)):
            training_epochs[idx] += training_epoch
            checkpoint = torch.load(
                "./checkpoints/halving_checkpoint%.5f.pt" % (weight_list[idx]))

            # load the model, optimizer and lr_scheduler
            model = Model()
            model.load_state_dict(checkpoint['model_state_dict'])
            model.to(device)
            optimizer = torch.optim.Adam(model.parameters(), lr)
            optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
            lr_scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
                optimizer=optimizer)
            lr_scheduler.load_state_dict(
                checkpoint['lr_scheduler_state_dict'])

            _, rates[idx] = train_eval_halving(train_loader=train_loader, eval_loader=eval_loader, model=model, optimizer=optimizer,
                                                        weight=weight_list[idx], sigma=sigma, epoch_num=training_epoch, lr_scheduler=lr_scheduler)

            torch.save({'model_state_dict': model.state_dict(),
                        'optimizer_state_dict': optimizer.state_dict(), 'lr_scheduler_state_dict': lr_scheduler.state_dict()}, "./checkpoints/checkpoint%.5f.pt" % (weight_list[idx]))
            print("model%.3f achieve rate %.2f after %d epochs' training." % (
                weight_list[idx], rates[idx], training_epochs[idx]))

        _, indices = torch.sort(rates)

        # discard the worst half of the models
        rates = rates[indices[int(len(weight_list)/2):]]
        training_epochs = training_epochs[indices[int(len(weight_list)/2):]]
        weight_list = weight_list[indices[int(len(weight_list)/2):]]
        print("Current weight list:", weight_list)


if __name__ == '__main__':
    main()
