'''
 @ File: main.py
 @ Time: 2022/10/15
 @ Description: Run this script to train and evaluate the model. The loss function type could be changed by modifying Line 32,70-76.
'''
import torch
import numpy as np
import scipy.io as sio
import time
from utils.dataset import CSIDataset
from torch.utils.data import DataLoader
from models.model import Model
from utils.train_eval import train_eval
from utils.eval import eval


def main(training_time=5, epoch_num=600, batch_size=64, sigma=2.26e-10, lr=1e-4):
    """main function. Run this function to train and evaluate the model. Results are saved in MATLAB data file.

    Args:
        training_time (int, optional): training times. Defaults to 5.
        epoch_num (int, optional): epoch number in each training time. Defaults to 600.
        batch_size (int, optional): batch size. Defaults to 64.
        sigma (float, optional): power of additive gauss noise. Defaults to 2.26e-10.
        lr (float, optional): learning rate. Defaults to 1e-4.
    """

    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    cur_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    train_folder = './data/train'
    eval_folder = './data/validation'
    weight = 405.3198*2**-3
    num_RB = 8
    version_name = 'Sumloss%.2f' % (weight)

    print(version_name)
    print('device:%s' % device)
    print('batch_size:%d' % batch_size)
    print('sigma:%e' % sigma)
    print('lr:%e' % (lr))
    print('cur_time:%s' % cur_time)
    print('weight=%.3f' % weight)
    print('-----------------------------------')

    train_set = CSIDataset(path=train_folder,
                           batch_size=batch_size,
                           device=device)
    eval_set = CSIDataset(path=eval_folder,
                          batch_size=batch_size,
                          device=device)

    train_loader = DataLoader(train_set, batch_size=batch_size, shuffle=True)
    eval_loader = DataLoader(eval_set, batch_size=batch_size, shuffle=False)

    loss_train = np.zeros((training_time, epoch_num))
    # 10: 10 times eval in each epoch
    loss_eval = np.zeros((num_RB, training_time, epoch_num * 10 + 1))

    for idx in range(training_time):
        print('Train %dth time' % (idx+1))

        model = Model().to(device)
        optimizer = torch.optim.Adam(model.parameters(), lr)

        # evaluate the model before training
        rate = eval(model, eval_loader, sigma)
        loss_eval[:, idx, 0] = rate

        for epoch in range(epoch_num):
            ############################
            # L1Loss/MSELoss: set use_fused_loss=False and modify Line 29 in utils/train_eval.py;
            # RateLoss: set use_fused_loss=True, weight=0;
            # FusedLoss: set use_fused_loss=True, weight>0;
            epoch_loss_train, epoch_loss_eval = train_eval(model, train_loader, eval_loader,
                                                           optimizer, weight, sigma, use_fused_loss=True)
            ############################
            loss_train[idx, epoch] = epoch_loss_train
            loss_eval[:, idx, epoch*10+1:(epoch+1)*10+1] = epoch_loss_eval

            rate_losses = epoch_loss_eval[:, -1]

            print('Epoch %d eval rate:%.2f' %
                  (epoch, np.mean(rate_losses.squeeze())))

            # save models
            if (epoch + 1) % 5 == 0:
                checkpoint_name = './checkpoints/' + \
                    version_name + '_checkpoint' + str(idx) + '.pt'

                checkpoint = {
                    'epoch': epoch,
                    'model_state_dict': model.state_dict(),
                    'optimizer_state_dict': optimizer.state_dict()
                }
                torch.save(checkpoint, checkpoint_name)

            # save results into mat file
            mat_name = './record/' + version_name + '_result.mat'
            sio.savemat(mat_name, {
                'loss_eval': loss_eval,
            })


if __name__ == '__main__':
    main()
